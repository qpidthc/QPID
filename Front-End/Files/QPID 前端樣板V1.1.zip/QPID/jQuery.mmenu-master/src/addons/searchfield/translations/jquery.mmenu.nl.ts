(function( $ ) {

	var _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Search'			: 'Zoeken',
		'No results found.'	: 'Geen resultaten gevonden.',
		'Search results'	: 'Zoekresultaten'
	});

})( jQuery );